package com.aimlock.app

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ProgressBar

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var progress: ProgressBar

    private val userUrl = "https://ngocnhung160177-lang.github.io/aimlock-webclip/"
    private val adminUrl = "https://aimlock-backend-1.onrender.com/admin.html"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(11, 15, 29)
        window.navigationBarColor = Color.rgb(11, 15, 29)
        window.decorView.systemUiVisibility = 0

        val frame = FrameLayout(this).apply {
            setBackgroundColor(Color.rgb(11, 15, 29))
        }

        webView = WebView(this).apply {
            setBackgroundColor(Color.rgb(11, 15, 29))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.allowFileAccess = false
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    url: String?
                ): Boolean {
                    if (url == adminUrl) {
                        view?.loadUrl(adminUrl)
                        return true
                    }
                    return false
                }
            }
            webChromeClient = WebChromeClient()
        }

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            setBackgroundColor(Color.TRANSPARENT)
        }

        frame.addView(webView, FrameLayout.LayoutParams(-1, -1))
        frame.addView(progress, FrameLayout.LayoutParams(-1, 4))
        setContentView(frame)

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress >= 100) View.GONE else View.VISIBLE
            }
        }

        webView.loadUrl(userUrl)
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
