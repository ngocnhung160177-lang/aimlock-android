AIMLOCK Android - giao dien Web Clip, KHONG CO DNS

Ung dung mo truc tiep website AIMLOCK nguoi dung trong man hinh toan man hinh:
https://ngocnhung160177-lang.github.io/aimlock-webclip/

Giao dien nhap key, chuc nang VIP/thuong va cai dat duoc lay tu website,
nen can mang internet. Khong co nut DNS, khong co thanh dieu huong them.

Admin tao key van dung trang rieng:
https://aimlock-backend-1.onrender.com/admin.html

Build APK:
1. Tao repository GitHub moi va upload toan bo noi dung thu muc du an.
2. Vao Actions > Build AIMLOCK APK > Run workflow.
3. Khi build xong, tai artifact AIMLOCK-debug-apk va giai nen.
4. File app-debug.apk la ban debug de thu nghiem.

Luu y: day la APK WebView, cac cong tac tren website chi doi trang thai hien thi,
khong can thiep vao game.
